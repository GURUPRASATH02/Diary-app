// moment.dart
import 'dart:io';

class Moment {
  final String details;
  final File? image;

  Moment(this.details, this.image);
}
